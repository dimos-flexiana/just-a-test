print('Hi Terje')

